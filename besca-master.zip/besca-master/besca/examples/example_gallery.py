"""
Title of example
================

Here goes your description of the example
"""

# start writing some code

###############################################################################
# sub heading
# -----------
#
# Here you add additional text you want to include
# there is no need to finish this section with any specific syntax
# just leave a line empty after this comment

# more code

###############################################################################
# this is an additional text comment without a heading
# this is more of that comment

# more code
