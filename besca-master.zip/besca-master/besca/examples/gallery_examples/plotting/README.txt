Plotting examples
-----------------

This is a gallery containing some plotting examples.


