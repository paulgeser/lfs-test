Preprocessing
-------------

This section highlights some of the features of the preprocessing functions included within BESCA.