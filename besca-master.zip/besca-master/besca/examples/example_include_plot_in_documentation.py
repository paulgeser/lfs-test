"""
...

Example
-------

Description of your example.

>>> # this is code that will be displayed but not executed
>>> # it should be a duplicate of the code used to generate the plot 
>>> #  people will not be able to see how you generated the plot
>>> ## plotting code 1
>>> ## plotting code 2

.. plot:: 

    >>> # this is code that will be displayed but not executed
    >>> # it should be a duplicate of the code used to generate the plot 
    >>> #  people will not be able to see how you generated the plot
    >>> ## plotting code 1
    >>> ## plotting code 2
    
"""
