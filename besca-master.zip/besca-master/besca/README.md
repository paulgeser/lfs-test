# Overview of Abbreviations

pp = preprocessing   
tl = tools  
pl = plotting  
st = standardpipeline  
Import = importing functions (note that we did not use `import` as module
because it is a keyword) 
export = exporting functions
