# Documentation of Abbreviations

bcor = batch correction  
rc = reclustering  
dge = differential gene expression  
sig = signature scoring  
