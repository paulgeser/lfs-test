
:orphan:

.. _sphx_glr_auto_examples_tools_sg_execution_times:

Computation times
=================
**00:13.716** total execution time for **auto_examples_tools** files:

+-------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_tools_plot_reclustering_function.py` (``plot_reclustering_function.py``) | 00:13.716 | 0.0 MB |
+-------------------------------------------------------------------------------------------------------+-----------+--------+
