
:orphan:

.. _sphx_glr_auto_examples_workflows_sg_execution_times:

Computation times
=================
**00:22.833** total execution time for **auto_examples_workflows** files:

+-------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_workflows_plot_celltype_annotation.py` (``plot_celltype_annotation.py``) | 00:22.833 | 0.0 MB |
+-------------------------------------------------------------------------------------------------------+-----------+--------+
