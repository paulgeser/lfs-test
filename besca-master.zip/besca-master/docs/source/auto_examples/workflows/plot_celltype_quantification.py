"""
Visualize Cell Fractions
========================

This example demonstrates how to generate celltype quantification plots.

"""

import besca as bc 

#import dataset to workwith

adata = bc.datasets.pbmc3k_processed()

#continue with rest
