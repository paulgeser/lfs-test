
:orphan:

.. _sphx_glr_auto_examples_preprocessing_sg_execution_times:

Computation times
=================
**41:07.887** total execution time for **auto_examples_preprocessing** files:

+---------------------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_preprocessing_plot_pca_neighbors_clustering.py` (``plot_pca_neighbors_clustering.py``) | 41:07.887 | 0.0 MB |
+---------------------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_preprocessing_plot_example_filtering.py` (``plot_example_filtering.py``)               | 00:00.000 | 0.0 MB |
+---------------------------------------------------------------------------------------------------------------------+-----------+--------+
