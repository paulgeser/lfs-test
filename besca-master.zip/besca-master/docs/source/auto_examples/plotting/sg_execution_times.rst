
:orphan:

.. _sphx_glr_auto_examples_plotting_sg_execution_times:

Computation times
=================
**00:52.692** total execution time for **auto_examples_plotting** files:

+--------------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_plotting_plot_split_gene_expression.py` (``plot_split_gene_expression.py``)     | 00:27.807 | 0.0 MB |
+--------------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_plotting_plot_celltype_quantification.py` (``plot_celltype_quantification.py``) | 00:14.820 | 0.0 MB |
+--------------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_plotting_plot_qc.py` (``plot_qc.py``)                                           | 00:07.755 | 0.0 MB |
+--------------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_plotting_plot_filtering.py` (``plot_filtering.py``)                             | 00:01.581 | 0.0 MB |
+--------------------------------------------------------------------------------------------------------------+-----------+--------+
| :ref:`sphx_glr_auto_examples_plotting_plot_riverplot.py` (``plot_riverplot.py``)                             | 00:00.729 | 0.0 MB |
+--------------------------------------------------------------------------------------------------------------+-----------+--------+
