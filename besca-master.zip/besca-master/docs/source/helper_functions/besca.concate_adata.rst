﻿besca.concate\_adata
====================

.. currentmodule:: besca

.. autofunction:: concate_adata