﻿besca.subset\_adata
===================

.. currentmodule:: besca

.. autofunction:: subset_adata