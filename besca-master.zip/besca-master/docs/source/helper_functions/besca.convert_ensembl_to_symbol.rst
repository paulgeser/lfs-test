﻿besca.convert\_ensembl\_to\_symbol
==================================

.. currentmodule:: besca

.. autofunction:: convert_ensembl_to_symbol