﻿besca.get\_raw
==============

.. currentmodule:: besca

.. autofunction:: get_raw