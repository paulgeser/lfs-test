﻿besca.convert\_symbol\_to\_ensembl
==================================

.. currentmodule:: besca

.. autofunction:: convert_symbol_to_ensembl