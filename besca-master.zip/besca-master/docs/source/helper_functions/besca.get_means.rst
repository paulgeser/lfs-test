﻿besca.get\_means
================

.. currentmodule:: besca

.. autofunction:: get_means