﻿besca.get\_ameans
=================

.. currentmodule:: besca

.. autofunction:: get_ameans