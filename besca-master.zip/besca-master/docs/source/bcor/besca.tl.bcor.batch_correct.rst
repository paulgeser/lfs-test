batch_correct
=============

.. currentmodule:: besca.tl.bcor

.. autofunction:: batch_correct
