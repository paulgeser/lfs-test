postprocess_mnnpy
=================

.. currentmodule:: besca.tl.bcor

.. autofunction:: postprocess_mnnpy
