annotate_new_cellnames
======================

.. currentmodule:: besca.tl.rc

.. autofunction:: annotate_new_cellnames
