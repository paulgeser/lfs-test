frac_reads
==========

.. currentmodule:: besca.pp

.. autofunction:: frac_reads
