export_regressedOut
===================

.. currentmodule:: besca.st

.. autofunction:: export_regressedOut
