analysis_metadata
=================

.. currentmodule:: besca.export

.. autofunction:: analysis_metadata
