dot_heatmap_split_greyscale
===========================

.. currentmodule:: besca.pl

.. autofunction:: dot_heatmap_split_greyscale
