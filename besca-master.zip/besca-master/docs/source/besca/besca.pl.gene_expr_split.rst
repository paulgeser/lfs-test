gene_expr_split
===============

.. currentmodule:: besca.pl

.. autofunction:: gene_expr_split
