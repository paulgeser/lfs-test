additional_labeling
===================

.. currentmodule:: besca.st

.. autofunction:: additional_labeling
