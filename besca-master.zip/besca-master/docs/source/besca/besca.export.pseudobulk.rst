pseudobulk
==========

.. currentmodule:: besca.export

.. autofunction:: pseudobulk
