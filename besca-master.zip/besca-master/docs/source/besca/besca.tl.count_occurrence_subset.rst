count_occurrence_subset
======================

.. currentmodule:: besca.tl

.. autofunction:: count_occurrence_subset
