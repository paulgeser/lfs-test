max_genes
=========

.. currentmodule:: besca.pl

.. autofunction:: max_genes
