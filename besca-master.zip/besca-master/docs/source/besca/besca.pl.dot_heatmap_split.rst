dot_heatmap_split
=================

.. currentmodule:: besca.pl

.. autofunction:: dot_heatmap_split
