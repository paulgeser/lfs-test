library_size
============

.. currentmodule:: besca.pl

.. autofunction:: library_size
