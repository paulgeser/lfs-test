frac_pos
========

.. currentmodule:: besca.pp

.. autofunction:: frac_pos
