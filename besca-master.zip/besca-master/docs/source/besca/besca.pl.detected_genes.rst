detected_genes
==============

.. currentmodule:: besca.pl

.. autofunction:: detected_genes
