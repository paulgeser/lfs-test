dropouts
========

.. currentmodule:: besca.pl

.. autofunction:: dropouts
