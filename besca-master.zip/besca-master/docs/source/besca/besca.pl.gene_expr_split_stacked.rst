gene_expr_split_stacked
=======================

.. currentmodule:: besca.pl

.. autofunction:: gene_expr_split_stacked
