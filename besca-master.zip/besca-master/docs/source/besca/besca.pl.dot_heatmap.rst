dot_heatmap
===========

.. currentmodule:: besca.pl

.. autofunction:: dot_heatmap
