read_mtx
========

.. currentmodule:: besca.Import

.. autofunction:: read_mtx
