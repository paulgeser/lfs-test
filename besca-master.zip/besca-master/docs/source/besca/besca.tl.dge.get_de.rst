get_de
======

.. currentmodule:: besca.tl.dge

.. autofunction:: get_de
