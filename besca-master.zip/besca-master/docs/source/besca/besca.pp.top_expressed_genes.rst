top_expressed_genes
===================

.. currentmodule:: besca.pp

.. autofunction:: top_expressed_genes
