celllabel_quant_stackedbar
==========================

.. currentmodule:: besca.pl

.. autofunction:: celllabel_quant_stackedbar
