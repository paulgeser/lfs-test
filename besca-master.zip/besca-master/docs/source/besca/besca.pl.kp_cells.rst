kp_cells
========

.. currentmodule:: besca.pl

.. autofunction:: kp_cells
