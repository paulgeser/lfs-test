top_genes_counts
================

.. currentmodule:: besca.pl

.. autofunction:: top_genes_counts
