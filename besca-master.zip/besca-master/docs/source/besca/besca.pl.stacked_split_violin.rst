stacked_split_violin
====================

.. currentmodule:: besca.pl

.. autofunction:: stacked_split_violin
