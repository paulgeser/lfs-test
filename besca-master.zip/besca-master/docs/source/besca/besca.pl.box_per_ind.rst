box_per_ind
===========

.. currentmodule:: besca.pl

.. autofunction:: box_per_ind
