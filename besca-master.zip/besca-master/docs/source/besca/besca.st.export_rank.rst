export_rank
===========

.. currentmodule:: besca.st

.. autofunction:: export_rank
