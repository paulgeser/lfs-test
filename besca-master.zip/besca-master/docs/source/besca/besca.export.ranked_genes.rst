ranked_genes
============

.. currentmodule:: besca.export

.. autofunction:: ranked_genes
