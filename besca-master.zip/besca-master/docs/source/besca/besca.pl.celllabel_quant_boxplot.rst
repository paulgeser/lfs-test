celllabel_quant_boxplot
=======================

.. currentmodule:: besca.pl

.. autofunction:: celllabel_quant_boxplot
