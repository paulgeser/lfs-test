normalize_geometric
===================

.. currentmodule:: besca.pp

.. autofunction:: normalize_geometric
