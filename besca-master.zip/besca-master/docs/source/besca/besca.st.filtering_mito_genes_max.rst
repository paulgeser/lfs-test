filtering_mito_genes_max
========================

.. currentmodule:: besca.st

.. autofunction:: filtering_mito_genes_max
