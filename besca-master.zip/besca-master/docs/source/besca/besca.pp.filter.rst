filter
======

.. currentmodule:: besca.pp

.. autofunction:: filter
