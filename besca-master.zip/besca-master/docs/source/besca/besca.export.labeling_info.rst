labeling_info
=============

.. currentmodule:: besca.export

.. autofunction:: labeling_info
