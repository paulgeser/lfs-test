count_occurrence
===============

.. currentmodule:: besca.tl

.. autofunction:: count_occurrence
