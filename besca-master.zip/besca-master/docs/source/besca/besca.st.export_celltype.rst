export_celltype
===============

.. currentmodule:: besca.st

.. autofunction:: export_celltype
