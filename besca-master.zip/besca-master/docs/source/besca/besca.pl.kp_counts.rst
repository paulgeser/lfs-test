kp_counts
=========

.. currentmodule:: besca.pl

.. autofunction:: kp_counts
