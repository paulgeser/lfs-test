top_counts_genes
================

.. currentmodule:: besca.pp

.. autofunction:: top_counts_genes
