filter_gene_list
================

.. currentmodule:: besca.pp

.. autofunction:: filter_gene_list
