mean_expr
=========

.. currentmodule:: besca.pp

.. autofunction:: mean_expr
