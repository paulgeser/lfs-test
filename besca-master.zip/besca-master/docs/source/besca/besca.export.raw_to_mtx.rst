raw_to_mtx
==========

.. currentmodule:: besca.export

.. autofunction:: raw_to_mtx
