riverplot_2categories
=====================

.. currentmodule:: besca.pl

.. autofunction:: riverplot_2categories
