X_to_mtx
========

.. currentmodule:: besca.export

.. autofunction:: X_to_mtx
