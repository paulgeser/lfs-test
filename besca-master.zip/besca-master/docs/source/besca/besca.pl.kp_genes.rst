kp_genes
========

.. currentmodule:: besca.pl

.. autofunction:: kp_genes
