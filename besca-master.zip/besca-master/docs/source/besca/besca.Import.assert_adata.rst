assert_adata
============

.. currentmodule:: besca.Import

.. autofunction:: assert_adata
