max_mito
========

.. currentmodule:: besca.pl

.. autofunction:: max_mito
