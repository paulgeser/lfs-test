count_occurrence_subset_conditions
=================================

.. currentmodule:: besca.tl

.. autofunction:: count_occurrence_subset_conditions
