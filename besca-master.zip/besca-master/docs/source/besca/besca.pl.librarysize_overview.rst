librarysize_overview
====================

.. currentmodule:: besca.pl

.. autofunction:: librarysize_overview
