generate_gep
============

.. currentmodule:: besca.export

.. autofunction:: generate_gep
