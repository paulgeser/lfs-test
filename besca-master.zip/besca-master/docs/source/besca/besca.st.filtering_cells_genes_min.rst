filtering_cells_genes_min
=========================

.. currentmodule:: besca.st

.. autofunction:: filtering_cells_genes_min
