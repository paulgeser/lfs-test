max_counts
==========

.. currentmodule:: besca.pl

.. autofunction:: max_counts
