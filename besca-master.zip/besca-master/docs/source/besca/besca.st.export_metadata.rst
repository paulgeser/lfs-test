export_metadata
===============

.. currentmodule:: besca.st

.. autofunction:: export_metadata
