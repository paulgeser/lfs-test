labeling
========

.. currentmodule:: besca.export

.. autofunction:: labeling
