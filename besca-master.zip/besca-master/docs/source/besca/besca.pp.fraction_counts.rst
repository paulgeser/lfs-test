fraction_counts
===============

.. currentmodule:: besca.pp

.. autofunction:: fraction_counts
