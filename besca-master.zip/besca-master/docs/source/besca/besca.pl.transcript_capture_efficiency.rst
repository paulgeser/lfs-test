transcript_capture_efficiency
=============================

.. currentmodule:: besca.pl

.. autofunction:: transcript_capture_efficiency
