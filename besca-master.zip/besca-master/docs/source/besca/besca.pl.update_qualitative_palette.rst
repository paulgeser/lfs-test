update_qualitative_palette
==========================

.. currentmodule:: besca.pl

.. autofunction:: update_qualitative_palette
