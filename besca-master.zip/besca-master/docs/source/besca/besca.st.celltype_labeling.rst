celltype_labeling
=================

.. currentmodule:: besca.st

.. autofunction:: celltype_labeling
