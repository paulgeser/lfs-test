read_matrix
===========

.. currentmodule:: besca.st

.. autofunction:: read_matrix
