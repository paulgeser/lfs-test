perform_dge
===========

.. currentmodule:: besca.tl.dge

.. autofunction:: perform_dge
