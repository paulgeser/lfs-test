obtain_dblabel
==============

.. currentmodule:: besca.tl.sig

.. autofunction:: obtain_dblabel
