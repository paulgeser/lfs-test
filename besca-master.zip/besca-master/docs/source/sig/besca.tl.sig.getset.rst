getset
======

.. currentmodule:: besca.tl.sig

.. autofunction:: getset
