get_similar_geneset
===================

.. currentmodule:: besca.tl.sig

.. autofunction:: get_similar_geneset
