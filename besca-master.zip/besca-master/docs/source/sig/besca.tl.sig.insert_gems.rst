insert_gems
===========

.. currentmodule:: besca.tl.sig

.. autofunction:: insert_gems
