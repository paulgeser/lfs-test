make_anno
=========

.. currentmodule:: besca.tl.sig

.. autofunction:: make_anno
