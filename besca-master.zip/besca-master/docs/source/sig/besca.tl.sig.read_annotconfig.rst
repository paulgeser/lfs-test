read_annotconfig
================

.. currentmodule:: besca.tl.sig

.. autofunction:: read_annotconfig
