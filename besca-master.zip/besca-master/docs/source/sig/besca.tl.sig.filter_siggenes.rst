filter_siggenes
===============

.. currentmodule:: besca.tl.sig

.. autofunction:: filter_siggenes
