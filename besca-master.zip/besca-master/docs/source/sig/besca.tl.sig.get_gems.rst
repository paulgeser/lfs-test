get_gems
========

.. currentmodule:: besca.tl.sig

.. autofunction:: get_gems
