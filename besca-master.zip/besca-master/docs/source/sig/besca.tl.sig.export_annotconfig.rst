export_annotconfig
==================

.. currentmodule:: besca.tl.sig

.. autofunction:: export_annotconfig
