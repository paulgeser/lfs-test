compute_signed_score
====================

.. currentmodule:: besca.tl.sig

.. autofunction:: compute_signed_score
