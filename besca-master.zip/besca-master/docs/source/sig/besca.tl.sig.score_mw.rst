score_mw
========

.. currentmodule:: besca.tl.sig

.. autofunction:: score_mw
