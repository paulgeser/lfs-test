add_anno
========

.. currentmodule:: besca.tl.sig

.. autofunction:: add_anno
