read_GMT_sign
=============

.. currentmodule:: besca.tl.sig

.. autofunction:: read_GMT_sign
